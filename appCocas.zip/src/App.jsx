
import './App.css'

function App() {

	return (
		<div className='flex flex-col items-center m-5'>
			
		</div>
	)
}

export default App
